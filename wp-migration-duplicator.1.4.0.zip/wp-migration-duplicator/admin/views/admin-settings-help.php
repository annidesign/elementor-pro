<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}

?>
<div class="wf-tab-content" data-id="<?php echo $target_id;?>">

</div>